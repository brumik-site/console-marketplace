import pygame, tools

class App:
    def __init__(self):
        pass

    def update(self, updateList):
        event = updateList["event"]
        if event.type == pygame.JOYBUTTONDOWN:
            if event.button == tools.O_BUTTON: return 1

    def draw(self, drawList):
        screen = drawList["screen"]
        screen.fill((0, 0, 0))